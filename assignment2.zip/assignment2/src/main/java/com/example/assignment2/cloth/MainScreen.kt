package com.example.assignment2.cloth

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.assignment2.R

@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    val allParts = listOf(
        "arms", "ears", "eyebrows", "eyes", "glasses",
        "hat", "mouth", "mustache", "nose", "shoes"
    )

    val selectedParts = remember { mutableStateMapOf<String, Boolean>() }

    LaunchedEffect(Unit) {
        allParts.forEach { selectedParts[it] = true }
    }

    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    if (isPortrait) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text="202011319 심현목")
            Spacer(modifier=Modifier.height(12.dp))

            CharacterImage(selectedParts)
            Spacer(modifier = Modifier.height(16.dp))
            PartCheckboxGrid(allParts, selectedParts)
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text="202011319 심현목")
                Spacer(modifier=Modifier.height(12.dp))

                CharacterImage(selectedParts)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                PartCheckboxGrid(allParts, selectedParts)
            }
        }
    }
}

@Composable
fun CharacterImage(selectedParts: Map<String, Boolean>) {
    Box(
        modifier = Modifier
            .height(250.dp)
            .width(180.dp),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.body),
            contentDescription = "Body"
        )
        selectedParts.forEach { (part, isVisible) ->
            if (isVisible) {
                Image(
                    painter = painterResource(id = getImageResId(part)),
                    contentDescription = part
                )
            }
        }
    }
}

@Composable
fun PartCheckboxGrid(
    allParts: List<String>,
    selectedParts: MutableMap<String, Boolean>
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(allParts) { part ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = selectedParts[part] == true,
                    onCheckedChange = { selectedParts[part] = it }
                )
                Text(text = part)
            }
        }
    }
}

fun getImageResId(part: String): Int {
    return when (part) {
        "arms" -> R.drawable.arms
        "ears" -> R.drawable.ears
        "eyebrows" -> R.drawable.eyebrows
        "eyes" -> R.drawable.eyes
        "glasses" -> R.drawable.glasses
        "hat" -> R.drawable.hat
        "mouth" -> R.drawable.mouth
        "mustache" -> R.drawable.mustache
        "nose" -> R.drawable.nose
        "shoes" -> R.drawable.shoes
        else -> R.drawable.body
    }
}